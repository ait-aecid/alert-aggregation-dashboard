"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _elasticsearch = require("@elastic/elasticsearch");

var _fs = _interopRequireDefault(require("fs"));

var _jsYaml = _interopRequireDefault(require("js-yaml"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function defineRoutes(router) {
  let config = _jsYaml.default.safeLoad(_fs.default.readFileSync('/etc/kibana/aminer.yml', 'utf8'));

  let elasticHost = config.ELASTIC_HOST;
  const client = new _elasticsearch.Client({
    node: elasticHost,
    maxRetries: 5,
    requestTimeout: 60000,
    sniffOnStart: true
  });
  router.get({
    path: '/data',
    validate: false
  }, async (context, request, response) => {
    try {
      var error = null;
      var data = [];
      let {
        body
      } = request.url.query; // // const client = context.core.elasticsearch.client.asCurrentUser;

      const query = JSON.parse(body);
      const index = query.index;
      const indexExists = await client.indices.exists({
        index: index
      });

      if (indexExists.body) {
        data = await client.search(query).then(resp => {
          return resp.body;
        }).catch(error => {
          console.log(error.meta.body.error);
        });
      } else {
        error = "Index with name '" + index + "' does not exist in your elasticsearch instance.";
      }

      ;
      return response.ok({
        body: {
          data: data,
          error: error
        }
      });
    } catch (error) {
      console.log(error);
    }

    ;
  });
}

;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImNvbmZpZyIsInltbCIsInNhZmVMb2FkIiwiZnMiLCJyZWFkRmlsZVN5bmMiLCJlbGFzdGljSG9zdCIsIkVMQVNUSUNfSE9TVCIsImNsaWVudCIsIkNsaWVudCIsIm5vZGUiLCJtYXhSZXRyaWVzIiwicmVxdWVzdFRpbWVvdXQiLCJzbmlmZk9uU3RhcnQiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiZXJyb3IiLCJkYXRhIiwiYm9keSIsInVybCIsInF1ZXJ5IiwiSlNPTiIsInBhcnNlIiwiaW5kZXgiLCJpbmRleEV4aXN0cyIsImluZGljZXMiLCJleGlzdHMiLCJzZWFyY2giLCJ0aGVuIiwicmVzcCIsImNhdGNoIiwiY29uc29sZSIsImxvZyIsIm1ldGEiLCJvayJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUNBOztBQUNBOztBQUNBOzs7O0FBR08sU0FBU0EsWUFBVCxDQUFzQkMsTUFBdEIsRUFBdUM7QUFFNUMsTUFBSUMsTUFBTSxHQUFHQyxnQkFBSUMsUUFBSixDQUFhQyxZQUFHQyxZQUFILENBQWdCLHdCQUFoQixFQUEwQyxNQUExQyxDQUFiLENBQWI7O0FBQ0EsTUFBSUMsV0FBVyxHQUFHTCxNQUFNLENBQUNNLFlBQXpCO0FBRUEsUUFBTUMsTUFBTSxHQUFHLElBQUlDLHFCQUFKLENBQVc7QUFDdEJDLElBQUFBLElBQUksRUFBRUosV0FEZ0I7QUFFdEJLLElBQUFBLFVBQVUsRUFBRSxDQUZVO0FBR3RCQyxJQUFBQSxjQUFjLEVBQUUsS0FITTtBQUl0QkMsSUFBQUEsWUFBWSxFQUFFO0FBSlEsR0FBWCxDQUFmO0FBT0FiLEVBQUFBLE1BQU0sQ0FBQ2MsR0FBUCxDQUFXO0FBQ1RDLElBQUFBLElBQUksRUFBRSxPQURHO0FBRVRDLElBQUFBLFFBQVEsRUFBRTtBQUZELEdBQVgsRUFHRyxPQUFPQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDdkMsUUFBSTtBQUNGLFVBQUlDLEtBQUssR0FBRyxJQUFaO0FBQ0EsVUFBSUMsSUFBSSxHQUFHLEVBQVg7QUFDQSxVQUFJO0FBQUVDLFFBQUFBO0FBQUYsVUFBV0osT0FBTyxDQUFDSyxHQUFSLENBQVlDLEtBQTNCLENBSEUsQ0FJRjs7QUFDQSxZQUFNQSxLQUFLLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSixJQUFYLENBQWQ7QUFDQSxZQUFNSyxLQUFLLEdBQUdILEtBQUssQ0FBQ0csS0FBcEI7QUFFQSxZQUFNQyxXQUFXLEdBQUcsTUFBTXBCLE1BQU0sQ0FBQ3FCLE9BQVAsQ0FBZUMsTUFBZixDQUFzQjtBQUM5Q0gsUUFBQUEsS0FBSyxFQUFFQTtBQUR1QyxPQUF0QixDQUExQjs7QUFJQSxVQUFJQyxXQUFXLENBQUNOLElBQWhCLEVBQXNCO0FBQ3BCRCxRQUFBQSxJQUFJLEdBQUcsTUFBTWIsTUFBTSxDQUFDdUIsTUFBUCxDQUFjUCxLQUFkLEVBQXFCUSxJQUFyQixDQUEwQkMsSUFBSSxJQUFJO0FBQzdDLGlCQUFPQSxJQUFJLENBQUNYLElBQVo7QUFDRCxTQUZZLEVBRVZZLEtBRlUsQ0FFSGQsS0FBRCxJQUFXO0FBQ2xCZSxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWWhCLEtBQUssQ0FBQ2lCLElBQU4sQ0FBV2YsSUFBWCxDQUFnQkYsS0FBNUI7QUFDRCxTQUpZLENBQWI7QUFLRCxPQU5ELE1BTU87QUFDTEEsUUFBQUEsS0FBSyxHQUFHLHNCQUNKTyxLQURJLEdBRUosa0RBRko7QUFHRDs7QUFBQTtBQUVELGFBQU9SLFFBQVEsQ0FBQ21CLEVBQVQsQ0FBWTtBQUNqQmhCLFFBQUFBLElBQUksRUFBRTtBQUNKRCxVQUFBQSxJQUFJLEVBQUVBLElBREY7QUFFSkQsVUFBQUEsS0FBSyxFQUFFQTtBQUZIO0FBRFcsT0FBWixDQUFQO0FBTUQsS0E5QkQsQ0E4QkUsT0FBT0EsS0FBUCxFQUFjO0FBQ2RlLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZaEIsS0FBWjtBQUNEOztBQUFBO0FBQ0YsR0FyQ0Q7QUF1Q0Q7O0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJUm91dGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IENsaWVudCB9IGZyb20gJ0BlbGFzdGljL2VsYXN0aWNzZWFyY2gnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCB5bWwgZnJvbSAnanMteWFtbCc7XG5cblxuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcblxuICBsZXQgY29uZmlnID0geW1sLnNhZmVMb2FkKGZzLnJlYWRGaWxlU3luYygnL2V0Yy9raWJhbmEvYW1pbmVyLnltbCcsICd1dGY4JykpO1xuICBsZXQgZWxhc3RpY0hvc3QgPSBjb25maWcuRUxBU1RJQ19IT1NUO1xuXG4gIGNvbnN0IGNsaWVudCA9IG5ldyBDbGllbnQoe1xuICAgICAgbm9kZTogZWxhc3RpY0hvc3QsXG4gICAgICBtYXhSZXRyaWVzOiA1LFxuICAgICAgcmVxdWVzdFRpbWVvdXQ6IDYwMDAwLFxuICAgICAgc25pZmZPblN0YXJ0OiB0cnVlXG4gIH0pO1xuXG4gIHJvdXRlci5nZXQoe1xuICAgIHBhdGg6ICcvZGF0YScsXG4gICAgdmFsaWRhdGU6IGZhbHNlLFxuICB9LCBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICB0cnkge1xuICAgICAgdmFyIGVycm9yID0gbnVsbDtcbiAgICAgIHZhciBkYXRhID0gW107XG4gICAgICBsZXQgeyBib2R5IH0gPSByZXF1ZXN0LnVybC5xdWVyeTtcbiAgICAgIC8vIC8vIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgY29uc3QgcXVlcnkgPSBKU09OLnBhcnNlKGJvZHkpO1xuICAgICAgY29uc3QgaW5kZXggPSBxdWVyeS5pbmRleDtcblxuICAgICAgY29uc3QgaW5kZXhFeGlzdHMgPSBhd2FpdCBjbGllbnQuaW5kaWNlcy5leGlzdHMoe1xuICAgICAgICBpbmRleDogaW5kZXhcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoaW5kZXhFeGlzdHMuYm9keSkge1xuICAgICAgICBkYXRhID0gYXdhaXQgY2xpZW50LnNlYXJjaChxdWVyeSkudGhlbihyZXNwID0+IHtcbiAgICAgICAgICByZXR1cm4gcmVzcC5ib2R5O1xuICAgICAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvci5tZXRhLmJvZHkuZXJyb3IpICBcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlcnJvciA9IFwiSW5kZXggd2l0aCBuYW1lICdcIiBcbiAgICAgICAgICArIGluZGV4XG4gICAgICAgICAgKyBcIicgZG9lcyBub3QgZXhpc3QgaW4geW91ciBlbGFzdGljc2VhcmNoIGluc3RhbmNlLlwiXG4gICAgICB9O1xuICAgICAgICAgICAgICBcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBkYXRhOiBkYXRhLFxuICAgICAgICAgIGVycm9yOiBlcnJvcixcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgfTtcbiAgfSk7XG5cbn07XG4iXX0=